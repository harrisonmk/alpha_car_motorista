class StatusRequisicao {

  static const String AGUARDANDO = "aguardando";
  static const String A_CAMINHO = "a_caminho";
  static const String VIAGEM = "viagem";
  static const String FINALIZADA = "finalizada";
  static const String CONFIRMADA = "confirmada";
  static const String CANCELADA = "cancelada";






}