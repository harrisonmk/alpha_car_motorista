package com.app.alpha_car_motorista

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
